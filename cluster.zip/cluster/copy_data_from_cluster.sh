#!/bin/sh
i=50
j=-1
k=0.0001
l=0.0
#m=6e-8
#n=1
o=30
p=8
q=1
for m in {6e-8,1e-7}; do
    for p in {4,6,8,10}; do
      for i in {500,200,100,50,20,10,5,1}; do
        for k in {0.00001,0.00003,0.0001,0.0003,0.001,0.003,0.01}; do path="./data/4replicates_S"$p"P"$o"mu="$m"_dt_phage="$i"hour_dt_bact="$j"hour_Pamount="$k"_Bamount="$l"_replicate"$q"/";
              if [ ! -d $path ]
              then
                mkdir $path
              fi
              #cd "./"$path
              cd $path
              scp -r "twang92@cc-login.campuscluster.illinois.edu:/projects/physics/twang92/CRISPR_migration/4replicates_S"$p"P"$o"_mu="$m"_dt_phage="$i"hour_dt_bact="$j"hour_Pamount="$k"_Bamount="$l"_replicate"$q"/*time-series-data_replicate*.txt" ./
              #scp -r "twang92@cc-login.campuscluster.illinois.edu:/projects/physics/twang92/CRISPR_migration/4replicates_S"$p"P"$o"_mu="$m"_dt_phage="$i"hour_dt_bact="$j"hour_Pamount="$k"_Bamount="$l"_replicate"$q"/*similarity*.txt" ./
              cd ../../
            done
        done
    done
done
